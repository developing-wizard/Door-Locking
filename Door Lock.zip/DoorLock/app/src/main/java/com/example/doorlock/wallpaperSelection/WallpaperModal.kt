package com.example.doorlock.wallpaperSelection

data class WallpaperModal ( var ivwallpaper : Int)
