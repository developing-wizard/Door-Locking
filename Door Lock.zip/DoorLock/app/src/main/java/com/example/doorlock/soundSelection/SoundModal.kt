package com.example.doorlock.soundSelection

data class SoundModal( val soundimage :Int,
                    val resourdeid : Int ){

}