package com.example.doorlock.intruderDetect

data class IntruderModal(val imagePath: String){

}

