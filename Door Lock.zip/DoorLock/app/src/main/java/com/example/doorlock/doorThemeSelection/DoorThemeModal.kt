package com.example.doorlock.doorThemeSelection

data class DoorThemeModal(
    var doorimg: Int
)
